﻿Imports System.IO
Imports System.Security.Cryptography
Imports System.Text

Module AESPasswordEncryption
   Public secretKey As String = "MyStrongKey123456" ' Must be kept safe

   ' Encrypt a plain text string using AES
   Public Function EncryptString(plainText As String, key As String) As String
      Try
         ' Convert key to 32 bytes (256-bit key)
         Dim keyBytes As Byte() = New Byte(31) {}
         Dim tempKeyBytes As Byte() = Encoding.UTF8.GetBytes(key)
         Array.Copy(tempKeyBytes, keyBytes, Math.Min(tempKeyBytes.Length, keyBytes.Length))

         Using aes As Aes = Aes.Create()
            aes.Key = keyBytes
            aes.GenerateIV() ' Random IV for each encryption

            Using ms As New MemoryStream()
               ' Write IV at the start of the stream
               ms.Write(aes.IV, 0, aes.IV.Length)

               Using cs As New CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write)
                  Using sw As New StreamWriter(cs)
                     sw.Write(plainText)
                  End Using
               End Using

               ' Return Base64 string
               Return Convert.ToBase64String(ms.ToArray())
            End Using
         End Using

      Catch ex As Exception
         Throw New Exception("Encryption failed: " & ex.Message)

      End Try

   End Function

   ' Decrypt an AES encrypted string
   Public Function DecryptString(cipherText As String, key As String) As String
      Try
         Dim fullCipher As Byte() = Convert.FromBase64String(cipherText)

         ' Convert key to 32 bytes
         Dim keyBytes As Byte() = New Byte(31) {}
         Dim tempKeyBytes As Byte() = Encoding.UTF8.GetBytes(key)
         Array.Copy(tempKeyBytes, keyBytes, Math.Min(tempKeyBytes.Length, keyBytes.Length))

         Using aes As Aes = Aes.Create()
            aes.Key = keyBytes

            ' Extract IV from the start of the cipher
            Dim iv As Byte() = New Byte(aes.BlockSize \ 8 - 1) {}
            Array.Copy(fullCipher, 0, iv, 0, iv.Length)
            aes.IV = iv

            ' Extract encrypted data
            Dim cipherBytes As Byte() = New Byte(fullCipher.Length - iv.Length - 1) {}
            Array.Copy(fullCipher, iv.Length, cipherBytes, 0, cipherBytes.Length)

            Using ms As New MemoryStream(cipherBytes)
               Using cs As New CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Read)
                  Using sr As New StreamReader(cs)
                     Return sr.ReadToEnd()
                  End Using
               End Using
            End Using
         End Using

      Catch ex As Exception
         Throw New Exception("Decryption failed: " & ex.Message)

      End Try
   End Function

End Module
