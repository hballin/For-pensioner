﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_BrutForce
   Inherits System.Windows.Forms.Form

   'Form overrides dispose to clean up the component list.
   <System.Diagnostics.DebuggerNonUserCode()>
   Protected Overrides Sub Dispose(disposing As Boolean)
      Try
         If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
         End If
      Finally
         MyBase.Dispose(disposing)
      End Try
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()>
   Private Sub InitializeComponent()
      components = New ComponentModel.Container()
      Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_BrutForce))
      Button1 = New Button()
      Label1 = New Label()
      TextBox1 = New TextBox()
      Label2 = New Label()
      RichTextBox1 = New RichTextBox()
      Button2 = New Button()
      Label3 = New Label()
      Label4 = New Label()
      TextBox2 = New TextBox()
      Button3 = New Button()
      Label5 = New Label()
      Label6 = New Label()
      Label7 = New Label()
      Label8 = New Label()
      PictureBox1 = New PictureBox()
      CheckBox1 = New CheckBox()
      picSpin = New PictureBox()
      ToolTip1 = New ToolTip(components)
      btnLoadFile = New Button()
      CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
      CType(picSpin, ComponentModel.ISupportInitialize).BeginInit()
      SuspendLayout()
      ' 
      ' Button1
      ' 
      Button1.Location = New Point(264, 96)
      Button1.Name = "Button1"
      Button1.Size = New Size(104, 28)
      Button1.TabIndex = 0
      Button1.Text = "Liste einlesen"
      ToolTip1.SetToolTip(Button1, "Die Wortliste einlesen.")
      Button1.UseVisualStyleBackColor = True
      ' 
      ' Label1
      ' 
      Label1.AutoSize = True
      Label1.Location = New Point(12, 12)
      Label1.Name = "Label1"
      Label1.Size = New Size(67, 15)
      Label1.TabIndex = 1
      Label1.Text = "Dateiname:"
      ' 
      ' TextBox1
      ' 
      TextBox1.Location = New Point(84, 8)
      TextBox1.Name = "TextBox1"
      TextBox1.Size = New Size(584, 23)
      TextBox1.TabIndex = 2
      ToolTip1.SetToolTip(TextBox1, "Standardmäßig wird nur die Worliste !wordlist-german.txt! eingelesen." & vbCrLf & "Wenn eine andere Liste gewünscht ist, kann dies hier eingetragen bzw. geändert werden.")
      ' 
      ' Label2
      ' 
      Label2.AutoSize = True
      Label2.Location = New Point(12, 44)
      Label2.Name = "Label2"
      Label2.Size = New Size(57, 15)
      Label2.TabIndex = 3
      Label2.Text = "Wortliste:"
      ' 
      ' RichTextBox1
      ' 
      RichTextBox1.Location = New Point(8, 64)
      RichTextBox1.Name = "RichTextBox1"
      RichTextBox1.Size = New Size(244, 168)
      RichTextBox1.TabIndex = 4
      RichTextBox1.Text = ""
      ' 
      ' Button2
      ' 
      Button2.Location = New Point(264, 64)
      Button2.Name = "Button2"
      Button2.Size = New Size(104, 28)
      Button2.TabIndex = 5
      Button2.Text = "Liste auszählen"
      ToolTip1.SetToolTip(Button2, "Die Wortliste auszählen.")
      Button2.UseVisualStyleBackColor = True
      ' 
      ' Label3
      ' 
      Label3.AutoSize = True
      Label3.Font = New Font("Segoe UI", 9F, FontStyle.Bold)
      Label3.Location = New Point(88, 44)
      Label3.Name = "Label3"
      Label3.Size = New Size(10, 15)
      Label3.TabIndex = 6
      Label3.Text = " "
      ' 
      ' Label4
      ' 
      Label4.AutoSize = True
      Label4.Location = New Point(8, 240)
      Label4.Name = "Label4"
      Label4.Size = New Size(54, 15)
      Label4.TabIndex = 7
      Label4.Text = "Paßwort:"
      ' 
      ' TextBox2
      ' 
      TextBox2.Location = New Point(84, 236)
      TextBox2.Name = "TextBox2"
      TextBox2.Size = New Size(168, 23)
      TextBox2.TabIndex = 8
      TextBox2.Text = "Passwort"
      ToolTip1.SetToolTip(TextBox2, "Vorgabe eine bespielhaften Paßworts." & vbCrLf & "Dieses kann bei Bedarf hier nachbearbeitet werden.")
      ' 
      ' Button3
      ' 
      Button3.Location = New Point(264, 128)
      Button3.Name = "Button3"
      Button3.Size = New Size(104, 28)
      Button3.TabIndex = 9
      Button3.Text = "Paßwort suchen"
      ToolTip1.SetToolTip(Button3, "Nach dem verschlüsseltem/unverschlüsseltem Paßwort suchen.")
      Button3.UseVisualStyleBackColor = True
      ' 
      ' Label5
      ' 
      Label5.AutoSize = True
      Label5.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
      Label5.Location = New Point(88, 316)
      Label5.Name = "Label5"
      Label5.Size = New Size(10, 15)
      Label5.TabIndex = 11
      Label5.Text = " "
      ' 
      ' Label6
      ' 
      Label6.AutoSize = True
      Label6.Location = New Point(8, 316)
      Label6.Name = "Label6"
      Label6.Size = New Size(76, 15)
      Label6.TabIndex = 10
      Label6.Text = "Zeitaufwand:"
      ' 
      ' Label7
      ' 
      Label7.AutoSize = True
      Label7.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
      Label7.Location = New Point(88, 296)
      Label7.Name = "Label7"
      Label7.Size = New Size(10, 15)
      Label7.TabIndex = 13
      Label7.Text = " "
      ' 
      ' Label8
      ' 
      Label8.AutoSize = True
      Label8.Location = New Point(8, 296)
      Label8.Name = "Label8"
      Label8.Size = New Size(42, 15)
      Label8.TabIndex = 12
      Label8.Text = "Status:"
      ' 
      ' PictureBox1
      ' 
      PictureBox1.Location = New Point(432, 48)
      PictureBox1.Name = "PictureBox1"
      PictureBox1.Size = New Size(256, 176)
      PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
      PictureBox1.TabIndex = 15
      PictureBox1.TabStop = False
      ' 
      ' CheckBox1
      ' 
      CheckBox1.AutoSize = True
      CheckBox1.Location = New Point(12, 264)
      CheckBox1.Name = "CheckBox1"
      CheckBox1.Size = New Size(154, 19)
      CheckBox1.TabIndex = 16
      CheckBox1.Text = "Paßwortverschlüsselung"
      ToolTip1.SetToolTip(CheckBox1, "Die Paßwortverschlüsselung aktivieren/deaktivieren.")
      CheckBox1.UseVisualStyleBackColor = True
      ' 
      ' picSpin
      ' 
      picSpin.Image = My.Resources.Resources.loading_gif_transparent_25
      picSpin.Location = New Point(280, 176)
      picSpin.Name = "picSpin"
      picSpin.Size = New Size(76, 76)
      picSpin.SizeMode = PictureBoxSizeMode.StretchImage
      picSpin.TabIndex = 17
      picSpin.TabStop = False
      ' 
      ' btnLoadFile
      ' 
      btnLoadFile.BackgroundImage = My.Resources.Resources.open_folder
      btnLoadFile.BackgroundImageLayout = ImageLayout.Stretch
      btnLoadFile.Location = New Point(668, 8)
      btnLoadFile.Name = "btnLoadFile"
      btnLoadFile.Size = New Size(23, 23)
      btnLoadFile.TabIndex = 18
      ToolTip1.SetToolTip(btnLoadFile, "Neue Wortliste laden.")
      btnLoadFile.UseVisualStyleBackColor = True
      ' 
      ' frm_BrutForce
      ' 
      AutoScaleDimensions = New SizeF(7F, 15F)
      AutoScaleMode = AutoScaleMode.Font
      ClientSize = New Size(703, 341)
      Controls.Add(btnLoadFile)
      Controls.Add(picSpin)
      Controls.Add(CheckBox1)
      Controls.Add(Label7)
      Controls.Add(Label8)
      Controls.Add(Label5)
      Controls.Add(Label6)
      Controls.Add(Button3)
      Controls.Add(TextBox2)
      Controls.Add(Label4)
      Controls.Add(Label3)
      Controls.Add(Button2)
      Controls.Add(RichTextBox1)
      Controls.Add(Label2)
      Controls.Add(TextBox1)
      Controls.Add(Label1)
      Controls.Add(Button1)
      Controls.Add(PictureBox1)
      Icon = CType(resources.GetObject("$this.Icon"), Icon)
      Name = "frm_BrutForce"
      Text = "Brut-Force mit Paßwortliste"
      CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
      CType(picSpin, ComponentModel.ISupportInitialize).EndInit()
      ResumeLayout(False)
      PerformLayout()
   End Sub

   Friend WithEvents Button1 As Button
   Friend WithEvents Label1 As Label
   Friend WithEvents TextBox1 As TextBox
   Friend WithEvents Label2 As Label
   Friend WithEvents RichTextBox1 As RichTextBox
   Friend WithEvents Button2 As Button
   Friend WithEvents Label3 As Label
   Friend WithEvents Label4 As Label
   Friend WithEvents TextBox2 As TextBox
   Friend WithEvents Button3 As Button
   Friend WithEvents Label5 As Label
   Friend WithEvents Label6 As Label
   Friend WithEvents Label7 As Label
   Friend WithEvents Label8 As Label
   Friend WithEvents PictureBox1 As PictureBox
   Friend WithEvents CheckBox1 As CheckBox
   Friend WithEvents picSpin As PictureBox
   Friend WithEvents ToolTip1 As ToolTip
   Friend WithEvents btnLoadFile As Button

End Class
