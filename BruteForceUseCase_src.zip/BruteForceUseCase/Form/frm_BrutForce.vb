﻿Imports System.IO
Imports System.Text.RegularExpressions
Imports FA = System.Windows.Forms.Application

Public Class frm_BrutForce
   Dim filePath As String
   Dim fileText As String

   Public secretKey As String = "MyStrongKey123456" ' Must be kept safe

   Private Sub frm_BrutForce_Load(sender As Object, e As EventArgs) Handles MyBase.Load
      filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wordlist-german.txt")
      fileText = My.Computer.FileSystem.ReadAllText(filePath)

      Me.txtWordListFolder.Text = filePath
      Me.picSuccess.Image = Nothing
      Me.picSpin.Visible = False

      FA.DoEvents()

   End Sub

   Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnReadWordList.Click
      Me.picSuccess.Image = Global.BruteForceUseCase.My.Resources.Resources.Thinking
      FA.DoEvents()

      Try
         Dim wordPattern = "\b\w+\b"
         Dim matches = Regex.Matches(fileText, wordPattern)

         RichTextBox1.Text = fileText

      Catch ex As FileNotFoundException
         MsgBox("File not found: " & ex.Message)

      Catch ex As Exception
         MsgBox("Error reading file: " & ex.Message)

      End Try

      Me.picSuccess.Image = Nothing

   End Sub

   Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnCountWordList.Click
      Me.picSuccess.Image = Global.BruteForceUseCase.My.Resources.Resources.Thinking
      FA.DoEvents()

      Dim wordPattern As String = "\b\w+\b"
      Dim matches As MatchCollection = Regex.Matches(fileText, wordPattern)

      Me.picSuccess.Image = Nothing

      Me.Label3.Text = matches.Count.ToString("N0") & " (Anzahl)"

   End Sub

   Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnSeachPassword.Click
      Dim startTime As DateTime = DateTime.Parse(Now)
      Dim cipherTextOrg As String = Me.txtPasswordReal.Text
      Dim cipherTextNew As String
      Dim passwordFound As Boolean = False
      Dim password As String = String.Empty
      Dim passwordIndex As Integer = 0
      Dim fileNum As Short

      Me.picSuccess.Image = Nothing
      Me.picSpin.Visible = True
      FA.DoEvents()

      If Me.chkEnDecryptPassword.Checked Then
         cipherTextOrg = Me.txtPasswordReal.Text 'encrypted password

         fileNum = FreeFile()
         FileOpen(fileNum, filePath, OpenMode.Input)

         Do While Not EOF(fileNum)
            password = LineInput(fileNum)      'read password by password from password list
            passwordIndex += 1

            Dim wrapper As New Simple3Des(password)
            cipherTextNew = wrapper.EncryptData(secretKey)

            If cipherTextOrg = cipherTextNew Then
               passwordFound = True

               Exit Do

            End If

            FA.DoEvents()

         Loop

         FileClose(fileNum)

      Else
         cipherTextOrg = Me.txtPasswordReal.Text 'plain password

         fileNum = FreeFile()
         FileOpen(fileNum, filePath, OpenMode.Input)

         Do While Not EOF(fileNum)
            password = LineInput(fileNum)      'read password by password from password list
            passwordIndex += 1

            If cipherTextOrg = password Then
               passwordFound = True

               Exit Do

            End If

            FA.DoEvents()

         Loop

         FileClose(fileNum)

      End If

      If passwordFound Then
         Me.lblStatus.Text = "Das Paßwort """ & password & """ wurde ermittelt und steht an Position: " & passwordIndex.ToString("N0")
         Me.picSuccess.Image = Global.BruteForceUseCase.My.Resources.Resources.evrbddancen0w_76

      Else
         Me.lblStatus.Text = "Das Paßwort """ & password & """ konnte nicht ermittelt werden."
         Me.picSuccess.Image = Global.BruteForceUseCase.My.Resources.Resources.zonk


      End If

      Me.picSpin.Visible = False

      Dim endTime As DateTime = DateTime.Parse(Now)
      ' Calculate the difference
      Dim duration As TimeSpan = endTime - startTime

      Me.lblEstimatedTime.Text = duration.ToString

   End Sub

   Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles chkEnDecryptPassword.CheckedChanged
      Dim password = Me.txtPasswordReal.Text
      Dim secretKey = "MyStrongKey123456" ' Must be kept safe

      Me.picSuccess.Image = Nothing
      FA.DoEvents()

      If fileText.IndexOf(password, StringComparison.OrdinalIgnoreCase) > 0 Then
         Dim wrapper As New Simple3Des(password)
         Dim cipherText = wrapper.EncryptData(secretKey)

         Me.txtPasswordReal.Text = cipherText
         Me.txtPasswordReal.Tag = password 'plain password
         Me.txtPasswordReal.Enabled = False

      Else
         Me.txtPasswordReal.Text = Me.txtPasswordReal.Tag
         Me.txtPasswordReal.Enabled = True

         Me.chkEnDecryptPassword.Checked = False

      End If


   End Sub

   Private Sub btnLoadFile_Click(sender As Object, e As EventArgs) Handles btnLoadFile.Click
      Dim FileName As String

      Dim CmdDialg As New cls_ToolsClass
      FileName = CmdDialg.GetFileName(AppDomain.CurrentDomain.BaseDirectory, "<ateiname>.TXT (*.TXT)|*.TXT|*.EMF|All files (*.*)|*.*")

      If FileName.Length > 0 Then
         Me.txtWordListFolder.Text = FileName

      End If

   End Sub

   Private Sub txtPasswordReal_TextChanged(sender As Object, e As EventArgs) Handles txtPasswordReal.TextChanged
      Me.txtPasswordReal.Tag = Me.txtPasswordReal.Text

   End Sub

End Class
