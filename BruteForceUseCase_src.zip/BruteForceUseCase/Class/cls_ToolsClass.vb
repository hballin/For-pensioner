Public Class cls_ToolsClass
   Function GetFileName(ByVal OpenFolder As String, ByRef ImageFileExtension As String) As String
      Dim OpenFileDialog1 As OpenFileDialog
      OpenFileDialog1 = New OpenFileDialog()
      OpenFileDialog1.InitialDirectory = OpenFolder
      OpenFileDialog1.Filter = "TXT-Dateien (*.TXT)|*.TXT|Alle (*.*)|*.*"
      OpenFileDialog1.Title = "Textdatei w�hlen..."
      OpenFileDialog1.RestoreDirectory = True
      OpenFileDialog1.ShowDialog()

      Return OpenFileDialog1.FileName()

   End Function

End Class

